import httpx

class BaseDataLoader:

    def __init__(self, endpoint=None):
        self._base_url = endpoint

    async def _get_req(self, resource, params=None):
        async with httpx.AsyncClient() as client:
            req_url = self._base_url + resource
            response = await client.get(req_url, params=params)
            if response.status_code != 200:
                msg = f"Unable to request data from {req_url}, status: {response.status_code}"
                raise RuntimeError(msg)
            return response.text
